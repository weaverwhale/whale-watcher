(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/index.ts.152b5ef1.js")
    );
  })().catch(console.error);

})();
