console.info("whale watcher content script");
