console.info("whale watcher background script");
